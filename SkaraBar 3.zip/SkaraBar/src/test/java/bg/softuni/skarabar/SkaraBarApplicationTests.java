package bg.softuni.skarabar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkaraBarApplicationTests {

	@Test
	void contextLoads() {
	}

}
