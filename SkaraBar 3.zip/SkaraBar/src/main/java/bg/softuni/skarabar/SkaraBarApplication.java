package bg.softuni.skarabar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkaraBarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkaraBarApplication.class, args);
	}

}
